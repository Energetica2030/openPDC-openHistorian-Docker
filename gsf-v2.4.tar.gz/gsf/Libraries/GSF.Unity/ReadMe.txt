This solution is targeted for .NET 3.5 with a reduced code and reference set to accomodate Unity 3D.

Solution should be compiled with MonoDevelop or Visual Studio 2008.
