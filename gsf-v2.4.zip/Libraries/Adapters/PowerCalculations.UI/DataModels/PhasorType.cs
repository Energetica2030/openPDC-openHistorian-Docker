﻿namespace PowerCalculations.UI.DataModels
{
	public enum PhasorType
	{
		Any = 0,
		Voltage = 1,
		Current = 2
	}
}
