In order to use the MySqlOutputAdapter, you must first set up the database to which it will be writing measurements. Using the command prompt, change to this directory and use the following command.

mysql -uroot -p < MySqlOutputAdapter.sql

Enter your root password and a database by the name of OutputAdapter will be created for use with the MySqlOutputAdapter.